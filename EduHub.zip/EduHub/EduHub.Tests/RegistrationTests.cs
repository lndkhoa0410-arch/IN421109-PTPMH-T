﻿
using System;
using Xunit;
using EduHub.Domain.Entities;

namespace EduHub.Tests
{
    public class RegistrationTests
    {
        [Fact]
        public void Create_ValidIds_ShouldHavePendingStatus()
        {
            var registration = Registration.Create(
                Guid.NewGuid(),
                Guid.NewGuid());

            Assert.Equal(
                RegistrationStatus.Pending,
                registration.Status);
        }

        [Fact]
        public void Create_EmptyMemberId_ShouldThrowException()
        {
            Assert.Throws<ArgumentException>(() =>
                Registration.Create(
                    Guid.Empty,
                    Guid.NewGuid()));
        }

        [Fact]
        public void CancelThenConfirm_ShouldThrowAndRemainCancelled()
        {
            var registration = Registration.Create(
                Guid.NewGuid(),
                Guid.NewGuid());

            registration.Cancel();

            Assert.Throws<InvalidOperationException>(() =>
                registration.Confirm());

            Assert.Equal(
                RegistrationStatus.Cancelled,
                registration.Status);
        }
    }
}

