﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EduHub.Application.Interfaces
{
    public interface INotificationService
    {
        void Send(string message);
    }
}