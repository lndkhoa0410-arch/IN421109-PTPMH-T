using EduHub.Application.Interfaces;
using EduHub.Application.Services;
using EduHub.Infrastructure.Repositories;
using EduHub.Infrastructure.Notifications;
var builder = WebApplication.CreateBuilder(args);
builder.Services.AddSingleton<IEventRepository, InMemoryEventRepository>();

builder.Services.AddScoped<INotificationService>(provider =>
    NotificationFactory.Create("email"));

builder.Services.AddScoped<EventService>();

// Add services to the container.

builder.Services.AddControllers();
builder.Services.AddSwaggerGen();
// Learn more about configuring OpenAPI at https://aka.ms/aspnet/openapi
var app = builder.Build();
app.UseSwagger();
app.UseSwaggerUI();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())


app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
