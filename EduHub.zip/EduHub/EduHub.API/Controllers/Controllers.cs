﻿
using Microsoft.AspNetCore.Mvc;
using EduHub.Domain.Entities;
using EduHub.Application.Interfaces;
using System;
using System.Collections.Generic;

namespace EduHub.API.Controllers
{
    [ApiController]
    [Route("api")]
    public class EventsController : ControllerBase
    {
        private readonly IEventRepository _repository;

        public EventsController(IEventRepository repository)
        {
            _repository = repository;
        }

        // GET: api/clubs/{clubId}/events
        [HttpGet("clubs/{clubId:guid}/events")]
        public ActionResult<IEnumerable<Event>> GetByClub(Guid clubId)
        {
            return Ok(_repository.GetByClubId(clubId));
        }

        // GET: api/events/{id}
        [HttpGet("events/{id:guid}")]
        public ActionResult<Event> GetById(Guid id)
        {
            var eventItem = _repository.GetById(id);

            if (eventItem == null)
                return NotFound();

            return Ok(eventItem);
        }

        // POST: api/clubs/{clubId}/events
        [HttpPost("clubs/{clubId:guid}/events")]
        public ActionResult<Event> Create(
            Guid clubId,
            [FromBody] CreateEventRequest request)
        {
            var newEvent = Event.Create(
                clubId,
                request.Title,
                request.Date,
                request.Capacity);

            _repository.Add(newEvent);

            return CreatedAtAction(
                nameof(GetById),
                new { id = newEvent.Id },
                newEvent);
        }

        // DELETE: api/events/{id}
        [HttpDelete("events/{id:guid}")]
        public IActionResult Delete(Guid id)
        {
            var eventItem = _repository.GetById(id);

            if (eventItem == null)
                return NotFound();

            _repository.Delete(id);

            return NoContent();
        }
    }

    public class CreateEventRequest
    {
        public string Title { get; set; }
        public DateTime Date { get; set; }
        public int Capacity { get; set; }
    }
}

