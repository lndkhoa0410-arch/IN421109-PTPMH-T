﻿using EduHub.Application.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;

namespace EduHub.Infrastructure.Notifications
{
    public class SmsNotificationService : INotificationService
    {
        public void Send(string message)
        {
            Console.WriteLine("SMS: " + message);
        }
    }
}