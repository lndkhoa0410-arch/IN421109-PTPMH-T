﻿using EduHub.Application.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;

namespace EduHub.Infrastructure.Notifications
{
    public class NotificationFactory
    {
        public static INotificationService Create(string channel)
        {
            if (channel == "email")
                return new EmailNotificationService();

            if (channel == "sms")
                return new SmsNotificationService();

            throw new ArgumentException("Kênh thông báo không hợp lệ.");
        }
    }
}
